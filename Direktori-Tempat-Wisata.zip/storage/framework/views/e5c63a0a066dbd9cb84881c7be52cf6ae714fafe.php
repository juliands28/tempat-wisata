

<?php $__env->startSection('title'); ?>
    Dashboard - Your Best Travel Agent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- page content awal -->
                <div class="section-content section-dashboard-home" data-aos="fade-up">
                    <div class="container-fluid">
                        <div class="dashboard-heading">
                            <h2 class="dashboard-title">Dashboard</h2>
                            <p class="dashboard-subtitle">Selamat Datang di Dashboard</p>
                        </div>
                        <div class="dashboard-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card mb-2">
                                        <div class="card-body">
                                            <div class="row">
                                                <?php $itemTravel = 0 ?>
                                                    <?php $__empty_1 = true; $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <div class="col-6 col-md-4" data-aos="fade-up" data-aos-delay="<?php echo e($itemTravel+=100); ?>">
                                                            <a href="<?php echo e(route('travel.edit', $item->id)); ?>" class="component-products d-block">
                                                                <div class="products-thumbnail">
                                                                <div
                                                                    class="products-image"
                                                                    style="background-image: url('<?php echo e(Storage::url($item->image)); ?>')"
                                                                ></div>
                                                                </div>
                                                                <div class="products-text"><?php echo e($item->name); ?></div>
                                                                <div class="products-place"><?php echo e($item->city); ?>, <?php echo e($item->region); ?></div>
                                                                <div class="products-price">Harga RP.<?php echo e(number_format($item->price)); ?>/pax</div>
                                                            </a>
                                                        </div> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <div class="col-12 text-center py-5" data-aos="fade-up" data-aos-delay="100">No Packages Travel</div>
                                                    <?php endif; ?>               
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <!-- /#page-content-wrapper -->
        </div>
<!-- page content akhir -->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Direktori-Tempat-Wisata\resources\views/pages/admin/admin.blade.php ENDPATH**/ ?>