

<?php $__env->startSection('title'); ?>
    Dashboard - Your Best Travel Agent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- page content awal -->
<div class="page-dashboard">
        <div class="d-flex" id="wrapper" data-aos="fade-right">
            <!-- Sidebar -->
            <div class="border-right" id="sidebar-wrapper">
                <div class="sidebar-heading text-center">
                    <img src="/images/Tripsgent.svg" alt="" class="my-4" />
                </div>
                <div class="list-group list-group-flush">
                    <a href="/dashboard.html" class="list-group-item list-group-item-action active">Dashboard</a
            >
            <a
              href="/dashboard-products.html"
              class="list-group-item list-group-item-action"
              >Manage Travel</a
            >
            <a
              href="/dashboard-transactions.html"
              class="list-group-item list-group-item-action"
              >Ganti Password</a
            >
            <a
              href="/dashboard-settings.html"
              class="list-group-item list-group-item-action"
              >logout</a
            >
          </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
          <nav
            class="navbar navbar-store navbar-expand-lg navbar-light fixed-top"
            data-aos="fade-down" aria-label="Toggle navigation"          >
            <button
              class="btn btn-secondary d-md-none mr-auto mr-2"
              id="menu-toggle"
            >
              &laquo; Menu
            </button>

            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
          </nav>
          <!-- end nav -->

          <!-- page content -->
         <div id="page-content-wrapper">
          <nav
            class="navbar navbar-store navbar-expand-lg navbar-light fixed-top"
            data-aos="fade-down" aria-label="Toggle navigation"
          >
            <button
              class="btn btn-secondary d-md-none mr-auto mr-2"
              id="menu-toggle"
            >
              &laquo; Menu
            </button>

            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
                </nav>

                <div class="section-content section-dashboard-home" data-aos="fade-up">
                    <div class="container-fluid">
                        <div class="dashboard-heading">
                            <h2 class="dashboard-title">Dashboard</h2>
                            <p class="dashboard-subtitle">Selamat Datang di Dashboard</p>
                        </div>
                        <div class="dashboard-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card mb-2">
                                        <div class="card-body">
                                            <div class="dashboard-card-title">Customer</div>
                                            <div class="dashboard-card-subtitle">15,209</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <!-- /#page-content-wrapper -->
        </div>
    </div>
    </div>
<!-- page content akhir -->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Direktori-Tempat-Wisata\resources\views/pages/admin.blade.php ENDPATH**/ ?>