

<?php $__env->startSection('title'); ?>
    Dashboard - Your Best Travel Agent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- page content awal -->
          <!-- page content -->
                <div class="section-content section-dashboard-home" data-aos="fade-up">
                    <div class="container-fluid">
                        <div class="dashboard-heading">
                            <h2 class="dashboard-title">Dashboard</h2>
                            <p class="dashboard-subtitle">Selamat Datang di Dashboard</p>
                        </div>
                        <div class="dashboard-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card shadow mb-2 p-4">
                                        <div class="card-body">
                                          <div class="row">
                                            <div class="col-md-12">
                                              <div class="d-sm-flex align-items-center justify-content-between mb-4">
                                                  <h1 class="h3 mb-0 text-gray-800">Tambah Paket Travel</h1>
                                              </div>
                                            </div>
                                            <div class="col-md-12">
                                             <?php if($errors->any()): ?>
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($error); ?></li>                        
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>            
                                            <?php endif; ?>
                                                <form action="<?php echo e(route('travel.store')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                        <div class="col-md-8">
                                                        <div class="form-group">
                                                            <label for="name">Nama Wisata</label>
                                                            <input type="text" class="form-control" name="name" placeholder="name" value="<?php echo e(old('name')); ?>">
                                                        </div> 
                                                        <div class="form-group">
                                                            <label for="price">Harga</label>
                                                            <input type="number" class="form-control" name="price" placeholder="price" value="<?php echo e(old('price')); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="description">Deskripsi</label>
                                                            <textarea name="description" rows="10" class="d-block w-100 form-control"><?php echo e(old('description')); ?></textarea>
                                                        </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Kota</label>
                                                            <select name="city" class="form-control" required value="<?php echo e(old('city')); ?>">
                                                                <option value="Medan">Medan</option>
                                                                <option value="Bogor">Bogor</option>
                                                                <option value="Jakarta Utara">Jakarta Utara</option>
                                                            </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Provinsi</label>
                                                                <select name="region" class="form-control" required value="<?php echo e(old('region')); ?>">
                                                                    <option value="Sumatera Utara">Sumatera Utara</option>
                                                                    <option value="Jawa Barat">Jawa Barat</option>
                                                                    <option value="Jakarta">Jakarta</option>
                                                                </select>
                                                            </div>    
                                                            <div class="form-group">
                                                                <label for="latitude">titik latitude</label>
                                                                <input type="text" class="form-control" name="latitude" placeholder="latitude" value="<?php echo e(old('latitude')); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="longitude">Titik longitude</label>
                                                                <input type="text" class="form-control" name="longitude" placeholder="longitude" value="<?php echo e(old('longitude')); ?>">
                                                            </div>                                                           
                                                            <div class="form-group">
                                                                <label for="image">Image</label>
                                                                <input type="file" class="form-control img-thumbnail" name="image" placeholder="Image" class="form-control" required value="<?php echo e(old('image')); ?>">
                                                                
                                                            </div>
                                                        </div>
                                                    </div>  
                                                    <button type="submit" class="btn btn-primary btn-block">
                                                    Tambah Wisata  
                                                    </button> 
                                                </form>                                            
                                            </div>
                                          </div>                                          
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
    <!-- /#page-content-wrapper -->
        </div>
    
<!-- page content akhir -->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Direktori-Tempat-Wisata\resources\views/pages/admin/travel/create.blade.php ENDPATH**/ ?>