<footer>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <p class="pt-4 pb-4">2020 Copyright Travel. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>